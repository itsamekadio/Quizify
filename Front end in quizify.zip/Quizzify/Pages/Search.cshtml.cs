using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages
{
    public class SearchModel : PageModel
    {
        public void OnGet()
        {
        }
        //public IActionResult OnPost()
        //{
        //    //implement search function
        //}
    }
}
