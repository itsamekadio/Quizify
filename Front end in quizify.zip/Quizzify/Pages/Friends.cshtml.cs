using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages
{
    public class FriendsModel : PageModel
    {
        //[BindProperty]
        //public string friendsName { get; set; }
        public void OnGet()
        {
            //friendsName = "Hign Doe";
        }
    }
}
