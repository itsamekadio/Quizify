using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages
{
    public class ReportPlayerModel : PageModel
    {
        public void OnGet()
        {
        }
        //public IActionResult OnPost()
        //{
        //    //implement the function of the button
        //}
        //return Page();
    }
}
