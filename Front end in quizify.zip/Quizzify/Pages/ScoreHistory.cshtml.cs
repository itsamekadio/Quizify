using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzify.Pages
{
    public class ScoreHistoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
